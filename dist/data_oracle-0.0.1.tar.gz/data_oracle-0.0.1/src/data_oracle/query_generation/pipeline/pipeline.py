


class PipelineSqlGen:

    def __init__(self, _connector,):
        pass