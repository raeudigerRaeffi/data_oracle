from enum import Enum


