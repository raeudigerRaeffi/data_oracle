from  connectors.sqlalchemyconnector import SqlAlchemyConnector


if __name__ == "__main__":
    class _data:
        database_type = 'MySQL'
        username = 'freedb_raffasch12'
        password = '7$Wkv&5PAvxRab9'
        host = 'sql.freedb.tech'
        port = 3306
        database_name = 'freedb_TestDB899'

    connect_data = _data()
    connector = SqlAlchemyConnector(connect_data)
    tables = connector.return_table_names()
    views = connector.return_view_names()
    print(connector.return_db_layout())
    print("test")